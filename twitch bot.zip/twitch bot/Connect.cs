using System;

namespace twitch_bot
{
    class Connect
    {
        public static string input;

        public static string Input()
        {
            input = Console.ReadLine().ToString();
            
            return input;
        }

        public static string Channel()
        {
            string channel = input;

            return channel;
        }
        
        public static string Token()
        {
            string token = "by6eszvfgnf3zt0kwvcyo5yn6rgymv";

            return token;
        }

    }
}