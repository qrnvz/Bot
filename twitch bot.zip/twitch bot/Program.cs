﻿using System;
using System.Threading;

namespace twitch_bot
{
    class Program : Connect
    {
        public static Bot qrgdx = new Bot();
        public static Thread running = new Thread(new ThreadStart(Running));
        
        static void Main(string[] args)
        {
            Running();
            running.Start();
        }

        public static void Running()
        {
            Console.Write("Choose the channel: ");

            Input();

            qrgdx.Connect();
            Console.WriteLine($"Bot connected to {Channel()}");
            Console.WriteLine("");

            Console.Title = Channel();

            while(true)
            {

            }
        }       
    }
}
