using System;
using TwitchLib.Client.Events;
using TwitchLib.Client.Extensions;

namespace twitch_bot
{
    class Vanish : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            if(whiteListed)
            {                                 
                client.TimeoutUser(e.Command.ChatMessage.Channel, e.Command.ChatMessage.Username, TimeSpan.FromSeconds(1));
            }
            else
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} i need a mod to do that BibleThump");
            }
        }
    }
}