using System.Collections.Generic;
using System.Linq;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class RepeatMessages : Bot
    {
        public static void Run(OnMessageReceivedArgs e)
        { 
            if(target != "" || targetShuffle != "")
            {
                if(target == e.ChatMessage.Username)
                {
                    string message = e.ChatMessage.Message;
                    client.SendMessage(Channel(), message);
                }

                if(targetShuffle == e.ChatMessage.Username)
                {
                    List<string> input = new List<string>(e.ChatMessage.Message.Split(" "));

                    List<string> shuffled = input.OrderBy(i => rnd.Next()).ToList();
                    string result = string.Join(" ", shuffled);

                    client.SendMessage(Channel(), result);
                }
            }
        }
    }
}