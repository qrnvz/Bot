using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Stop : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            if(whiteList.Contains(e.Command.ChatMessage.Username))
            {
                target = "";
                targetShuffle = "";
            }
            else
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} you dont have a permission to do that");
            }
        }
    }
}