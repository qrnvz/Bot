using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Repeat : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            if(whiteList.Contains(e.Command.ChatMessage.Username))
            {
                try
                {
                    target = e.Command.ChatMessage.Message.Split(" ")[1].ToLower();
                }
                catch
                {
                    client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} please choose a target");
                }
            }
            else
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} you dont have a permission to do that");
            }
        }
    }
}