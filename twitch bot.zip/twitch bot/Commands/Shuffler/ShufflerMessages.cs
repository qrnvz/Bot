using System.Collections.Generic;
using System.Linq;
using System.Threading;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class ShufflerMessages : Bot
    {
        public static void Run(OnMessageReceivedArgs e)
        {   
            if(shufflerOn)
            {
                string message = e.ChatMessage.Message;

                if(message.Contains("⠄") || message.Contains("█") || message.Contains("⣿") || message.Contains("⡇")  || shuffledMessages.Contains(message) || shuffledMessages.Contains(shuffled))
                {

                }
                else if(message.Length > 249)
                {                            
                    Thread.Sleep(1000);

                    List<string> messageList = new List<string>(message.Split(" "));

                    List<string> shuffledList = messageList.OrderBy(i => rnd.Next()).ToList();

                    shuffled = string.Join(" ", shuffledList);

                    shuffledMessages.Add(message);
                    shuffledMessages.Add(shuffled);

                    client.SendMessage(Channel(), shuffled);

                    shuffled = "";
                }
            }
        }
    }
}