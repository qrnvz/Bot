using TwitchLib.Client;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Shuffler : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            if(e.Command.ChatMessage.Username == "qrgdx")
            {
                try
                {
                    if(e.Command.ChatMessage.Message.Split(" ")[1] == "on")
                    {
                        shufflerOn = true;
                    }
                    else if(e.Command.ChatMessage.Message.Split(" ")[1] == "off")
                    {
                        shufflerOn = false;
                    }
                    else
                    {
                        if(shufflerOn)
                        {
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} shuffler is currently on");
                        }
                        else if(!shufflerOn)
                        {
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} shuffler is currently off");
                        }
                    }
                }
                catch
                {
                    if(shufflerOn)
                    {
                        client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} shuffler is currently on");
                    }
                    else if(!shufflerOn)
                    {
                        client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} shuffler is currently off");
                    }
                }
            }
            else
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} you do not have a permission to do that");
            }
        }
    }
}