using System.Threading;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class QuizAnswer : Bot
    {
        public static void Run(OnMessageReceivedArgs e)
        {
            if(quizRunning)
            {
                if(e.ChatMessage.Message.ToLower().Contains(quizAnswer.ToLower()) && !quizAnswered)
                {
                    if(e.ChatMessage.Username == "qrgdx")
                    {
                        Thread.Sleep(1000);
                    }
                    else
                    {
                        Thread.Sleep(0);
                    }
                    switch(quizLang)
                    {
                        case "RU":
                        client.SendMessage(Channel(), $"@{e.ChatMessage.Username} правильно! верный ответ - {quot}{quizAnswer}{quot}");
                        break;

                        case "EN":
                        client.SendMessage(Channel(), $"@{e.ChatMessage.Username} correct! the answer is {quot}{quizAnswer}{quot}");
                        break;
                    }
                    quizAnswered = true;
                }
            }
        }
    }
}