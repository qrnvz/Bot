using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Quiz : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            string command = e.Command.ChatMessage.Message.Replace("#quiz ", "");

            switch(command)
            {
                case "start":
                case "start en":
                if(!quizRunning)
                {
                    if(whiteList.Contains(e.Command.ChatMessage.Username))
                    {
                        Task questionEN = new Task(QuestionEN);
                        Task answerEN = new Task(AnswerEN);

                        quizRunning = true;
                        quizStopped = false;

                        questionEN.Start();
                        answerEN.Start();
                    }
                    else
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} only mods, VIPs or broadcaster can start the quiz");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} только модераторы, VIPы или стример могут запускать викторину");
                            break;
                        }
                    }
                }
                else if(quizRunning)
                {
                    if(whiteList.Contains(e.Command.ChatMessage.Username))
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz is currently running, next question will arrive in {300 - quizQuestionTime} seconds (you can stop the quiz using {quot}#quiz stop{quot} command)");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина уже запущена, следущий вопрос появится через {300 - quizQuestionTime} секунд (вы можете остановить викторину используя команду {quot}#quiz stop{quot})");
                            break;
                        }
                    }
                    else
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz is currently running, next question will arrive in {300 - quizQuestionTime} seconds");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина уже запущена, следущий вопрос появится через {300 - quizQuestionTime} секунд");
                            break;
                        }         
                    }
                }
                break;

                case "start ru":
                if(!quizRunning)
                {
                    if(whiteList.Contains(e.Command.ChatMessage.Username))
                    {
                        Task questionRU = new Task(QuestionRU);
                        Task answerRU = new Task(AnswerRU);

                        quizRunning = true;
                        quizStopped = false;

                        questionRU.Start();
                        answerRU.Start();
                    }
                    else
                    {
                        client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} только модераторы, VIPы или стример могут запускать викторину");
                    }
                }
                else if(quizRunning)
                {
                    if(whiteList.Contains(e.Command.ChatMessage.Username))
                    {
                        client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина уже запущена, следущий вопрос появится через {300 - quizQuestionTime} секунд (вы можете остановить викторину используя команду {quot}#quiz stop{quot})");
                    }
                    else
                    {
                        client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина уже запущена, следущий вопрос появится через {300 - quizQuestionTime} секунд");
                    }
                }
                break;

                case "stop":
                if(quizRunning)
                {
                    if(whiteList.Contains(e.Command.ChatMessage.Username))
                    {
                        quizRunning = false;
                        quizStopped = true;

                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz has been stopped");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина была остановлена");
                            break;
                        }
                    }
                    else
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} only mods, VIPs or broadcaster can stop the quiz");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} только модераторы VIPы или стример могут остановить викторину");
                            break;
                        }    
                    }
                }
                else if(!quizRunning)
                {
                    if(whiteList.Contains(e.Command.ChatMessage.Username))
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz is not running currently (you can start it using {quot}#quiz start{quot} command)");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина не запущена (вы можете запустить викторину используя команду {quot}#quiz start ru{quot})");
                            break;
                        }
                    }
                    else
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz is not running currently");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина не запущена");
                            break;
                        }  
                    }
                }
                break;

                default:
                if(!quizRunning)
                {
                    if(whiteList.Contains(e.Command.ChatMessage.Username))
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz is not running currently (you can start it using {quot}#quiz start{quot} command)");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина не запущена (вы можете запустить викторину используя команду {quot}#quiz start ru{quot})");
                            break;
                        }
                    }
                    else
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz is not running currently");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина не запущена");
                            break;
                        }  
                    }
                }
                else if(quizRunning)
                {
                    if(whiteList.Contains(e.Command.ChatMessage.Username))
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz is currently running, next question will arrive in {300 - quizQuestionTime} seconds (you can stop the quiz using {quot}#quiz stop{quot} command)");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина уже запущена, следущий вопрос появится через {300 - quizQuestionTime} секунд (вы можете остановить викторину используя команду {quot}#quiz stop{quot})");
                            break;
                        }
                    }
                    else
                    {   
                        switch(quizLang)
                        {
                            case "EN":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} quiz is currently running, next question will arrive in {300 - quizQuestionTime} seconds");
                            break;

                            case "RU":
                            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} викторина уже запущена, следущий вопрос появится через {300 - quizQuestionTime} секунд");
                            break;
                        }         
                    }
                }
                break;
            }
        }

        public static void InfoEN()
        {
            string url = $"http://jservice.io/api/random?count=1";

            HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(url);
            HttpWebResponse httpWebResponse = (HttpWebResponse) httpWebRequest.GetResponse();

            string response;

            using(StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
            {
                response = streamReader.ReadToEnd();
            }

            List<QuizResponseEN> quizResponseEN = JsonConvert.DeserializeObject<List<QuizResponseEN>>(response);

            foreach(var item in quizResponseEN)
            {
                string annoingQuot = quot.ToString();

                quizAnswer = item.answer.Replace("<i>", "").Replace("</i>", "").Replace("&", " and ").Replace("\\'", "").Replace(annoingQuot, "").Replace("a ", "").Replace("an ", "").Replace("the ", "");
                quizQuestion = item.question;
                quizCategory = item.category.title;
            }

            Regex brackets = new Regex(@"\(([^\)]+)\)");
            brackets.Replace(quizAnswer, "");
        }

        public static void QuestionEN()
        {
            for(quizQuestionTime = 300; quizRunning; quizQuestionTime++)
            {   
                if(quizQuestionTime == 300)
                {   
                    InfoEN();

                    client.SendMessage(Channel(), $"The question from [{quizCategory}] category: {quizQuestion}");

                    Console.WriteLine("");
                    Console.WriteLine($"THE QUESTION IS <{quizQuestion}>");
                    Console.WriteLine("");
                    Console.WriteLine($"THE ANSWER IS <{quizAnswer}>");
                    Console.WriteLine("");
                    
                    quizQuestionTime = 0;
                    quizAnswerTime = 0;
                    quizAnswered = false;
                    quizLang = "EN";
                }

                Thread.Sleep(1000);

                if(quizStopped)
                {
                    return;
                }
            }
        }
        
        public static void AnswerEN()
        {
            for(quizAnswerTime = 0; quizRunning; quizAnswerTime++)
            {   
                if(quizAnswerTime == 60 && quizAnswered == false)
                {   
                    client.SendMessage(Channel(), $"no one gave the right answer, it was {quot}{quizAnswer}{quot}");
                    quizAnswered = true;
                }

                Thread.Sleep(1000);

                if(quizStopped)
                {
                    return;
                }
            }
        }

        public static void InfoRU()
        {
            string quizRandom = quizQuestionsRU[rnd.Next(0, quizQuestionsRU.Count())];

            quizUsedQuestions.Add(quizRandom);

            while(quizUsedQuestions.Contains(quizRandom))
            {
                quizRandom = quizQuestionsRU[rnd.Next(0, quizQuestionsRU.Count())];
            }

            quizQuestion = quizRandom.Split("*")[0];
            quizAnswer = quizRandom.Split("*")[1]; 
        }

        public static void QuestionRU()
        {
            for(quizQuestionTime = 300; quizRunning; quizQuestionTime++)
            {   
                if(quizQuestionTime == 300)
                {   
                    InfoRU();

                    client.SendMessage(Channel(), $"Вопрос викторины: {quizQuestion}");

                    Console.WriteLine("");
                    Console.WriteLine($"THE QUESTION IS <{quizQuestion}>");
                    Console.WriteLine("");
                    Console.WriteLine($"THE ANSWER IS <{quizAnswer}>");
                    Console.WriteLine("");
                    
                    quizQuestionTime = 0;
                    quizAnswerTime = 0;
                    quizAnswered = false;
                    quizLang = "RU";
                }

                Thread.Sleep(1000);

                if(quizStopped)
                {
                    return;
                }
            }

        }

        public static void AnswerRU()
        {
            for(quizAnswerTime = 0; quizRunning; quizAnswerTime++)
            {   
                if(quizAnswerTime == 60 && quizAnswered == false)
                {   
                    client.SendMessage(Channel(), $"Никто не дал правильного ответа, верный ответ - {quot}{quizAnswer}{quot}");
                    quizAnswered = true;
                }

                Thread.Sleep(1000);

                if(quizStopped)
                {
                    return;
                }
            }
        }
    }
    
    class QuizResponseEN
    {
        public string question {get; set;}
        public string answer {get; set;}
        public CategoryEN category {get;set;}
    }

    class CategoryEN
    {
        public string title {get; set;}
    }
}