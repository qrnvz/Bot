using TwitchLib.Client;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Command : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {

        }
    }
}