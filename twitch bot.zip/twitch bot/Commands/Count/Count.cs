using System;
using TwitchLib.Client.Events;
using Z.Expressions;

namespace twitch_bot
{
    class Count : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            string input = e.Command.ChatMessage.Message.Remove(0, 6);
            try
            {
                int calculations = Eval.Execute<int>(input);

                string result = Convert.ToString(calculations);

                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} result is {result}");
            }
            catch
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} i cant count this BibleThump");
            }
        }
    }
}