using TwitchLib.Client.Events;

namespace twitch_bot
{
    class PlayAnswer : Bot
    {
        public static void Run(OnMessageReceivedArgs e)
        {
            if(playAnswer != "")
            {
                if(e.ChatMessage.Message == playAnswer)
                {
                    client.SendMessage(Channel(), $"@{e.ChatMessage.Username} correct! the answer is {playAnswer}");
                    playAnswer = "";
                }
            }
        }
    }
}