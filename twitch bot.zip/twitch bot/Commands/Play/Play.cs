using System;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Play : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        { 
            try
            {
                string range1 = e.Command.ChatMessage.Message.Split(" ")[1];
                string range2 = e.Command.ChatMessage.Message.Split(" ")[2];

                int r1 = Convert.ToInt32(range1);
                int r2 = Convert.ToInt32(range2);

                int num1 = rnd.Next(r1, r2);
                int num2 = rnd.Next(r1, r2);


                string[] operators = {"+", "-"};
                string opt = operators[rnd.Next(0,2)];

                if(opt == "+")
                {
                    int question = num1 + num2;
                    playAnswer = Convert.ToString(question);

                    if(num1 < 0 && num2 < 0)
                    {
                        client.SendMessage(Channel(), $"({num1}) + ({num2}) = ?");
                    }
                    else if(num1 < 0)
                    {
                        client.SendMessage(Channel(), $"({num1}) + {num2} = ?");
                    }
                    else if(num2 < 0)
                    {
                        client.SendMessage(Channel(), $"{num1} + ({num2}) = ?");
                    }
                    else
                    {
                        client.SendMessage(Channel(), $"{num1} + {num2} = ?");
                    }
                }
                else if(opt == "-")
                {
                    int question = num1 - num2;
                    playAnswer = Convert.ToString(question);

                    if(num1 < 0 && num2 < 0)
                    {
                        client.SendMessage(Channel(), $"({num1}) - ({num2}) = ?");
                    }
                    else if(num1 < 0)
                    {
                        client.SendMessage(Channel(), $"({num1}) - {num2} = ?");
                    }
                    else if(num2 < 0)
                    {
                        client.SendMessage(Channel(), $"{num1} - ({num2}) = ?");
                    }
                    else
                    {
                        client.SendMessage(Channel(), $"{num1} - {num2} = ?");
                    }
                }
            }
            catch
            {
                int num1 = rnd.Next(-10, 10);
                int num2 = rnd.Next(-10, 10);

                string[] operators = {"+", "-"};
                string opt = operators[rnd.Next(0,2)];
      
                if(opt == "+")
                {
                    int question = num1 + num2;
                    playAnswer = Convert.ToString(question);

                    if(num1 < 0 && num2 < 0)
                    {
                        client.SendMessage(Channel(), $"({num1}) + ({num2}) = ?");
                    }
                    else if(num1 < 0)
                    {
                        client.SendMessage(Channel(), $"({num1}) + {num2} = ?");
                    }
                    else if(num2 < 0)
                    {
                        client.SendMessage(Channel(), $"{num1} + ({num2}) = ?");
                    }
                    else
                    {
                        client.SendMessage(Channel(), $"{num1} + {num2} = ?");
                    }
                }
                else if(opt == "-")
                {
                    int question = num1 - num2;
                    playAnswer = Convert.ToString(question);

                    if(num1 < 0 && num2 < 0)
                    {
                        client.SendMessage(Channel(), $"({num1}) - ({num2}) = ?");
                    }
                    else if(num1 < 0)
                    {
                        client.SendMessage(Channel(), $"({num1}) - {num2} = ?");
                    }
                    else if(num2 < 0)
                    {
                        client.SendMessage(Channel(), $"{num1} - ({num2}) = ?");
                    }
                    else
                    {
                        client.SendMessage(Channel(), $"{num1} - {num2} = ?");
                    }
                }
            }
        }
    }
}