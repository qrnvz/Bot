using System.IO;
using System.Linq;
using System.Net;
using Newtonsoft.Json;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Weather : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {   
            const string KEY = "1030a3eb9c950b27bff651881a6f9611";

            string[] input = e.Command.ChatMessage.Message.Split(" ");
            string city = null;

            for(int i = 1; i < input.Count(); i++)
            {
                city += input[i] + " ";
            }

            string url = $"http://api.weatherstack.com/current?access_key={KEY}&query={city}";

            HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(url);
            HttpWebResponse httpWebResponse = (HttpWebResponse) httpWebRequest.GetResponse();

            string response;

            using(StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
            {
                response = streamReader.ReadToEnd();
            }

            WeatherResponse weatherResponse = JsonConvert.DeserializeObject<WeatherResponse>(response);
            try
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} weather in {weatherResponse.location.name} ({weatherResponse.location.country}) - {weatherResponse.current.weather_descriptions[0]}, temperature: {weatherResponse.current.temperature}°C");
            }
            catch
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} sorry, i cant find this city");
            }          
        }
    }
    class WeatherResponse
    {
       public Location location {get; set;}
       public Current current {get; set;}
    }
    class Location
    {
        public string name {get; set;}
        public string country {get; set;}
    }
    class Current
    {
        public int temperature {get; set;}
        public string[] weather_descriptions {get; set;}
    }
}