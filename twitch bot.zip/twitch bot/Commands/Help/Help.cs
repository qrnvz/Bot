using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Help : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} bot created by qrgdx, commands information here -> https://github.com/qrnvz/Bot");
        }
    }
}