using System;
using System.Linq;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Pyramid : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {   
            if(whiteListed)
            {
                string[] input = e.Command.ChatMessage.Message.Split(" ");

                try
                {
                    string character = input[1];
                    int times = Convert.ToInt32(input[2]);

                    if(times >= 8)
                    {
                        times = 7;
                    }
                    else if(times < 0)
                    {
                        times = 3;
                    }

                    for(int i = 1; i <= times; i++)
                    {
                        string result = String.Concat(Enumerable.Repeat(character + " ", i));
                        client.SendMessage(Channel(), result);
                    }
                    for(int i = times - 1; i > 0; i--)
                    {              
                        string result = String.Concat(Enumerable.Repeat(character + " ", i));
                        client.SendMessage(Channel(), result);
                    }
                }
                catch
                {
                    string character = input[1];

                    for(int i = 1; i <= 3; i++)
                    {
                        string result = String.Concat(Enumerable.Repeat(character + " ", i));
                        client.SendMessage(Channel(), result);
                    }
                    for(int i = 2; i > 0; i--)
                    {              
                        string result = String.Concat(Enumerable.Repeat(character + " ", i));
                        client.SendMessage(Channel(), result);
                    }
                }
            }
            else
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} i need a VIP or mod to do that BibleThump");
            }
        }
    }
}