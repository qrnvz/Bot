using System;
using System.Linq;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Plus : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            try
            {   
                string[] input = e.Command.ChatMessage.Message.Split(" ");
                double number = Convert.ToDouble(input[1]);
                for(int i = 2; i < input.Count(); i++)
                {
                    double a = Convert.ToDouble(input[i]);
                    number += a;
                }
                string result = Convert.ToString(number);
                client.SendMessage(Channel(), result);
            }
            catch
            {
                client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} please only enter numbers");
            }
        }
    }
}