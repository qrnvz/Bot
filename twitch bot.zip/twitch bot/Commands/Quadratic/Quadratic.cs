using System;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Quadratic : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            try
            {
                string[] input = e.Command.ChatMessage.Message.Split(" ");
                double a = Convert.ToDouble(input[1]);
                double b = Convert.ToDouble(input[2]);
                double c = Convert.ToDouble(input[3]);

                double D = b*b - 4*a*c;
                switch(D)
                {
                    case 0:
                        double x = (-b + Math.Sqrt(D)) / (2 * a);
                        client.SendMessage(Channel(), $"D = {D}, x = {x}");
                    break;

                    case <0:
                        client.SendMessage(Channel(), $"D = {D}, no roots");
                    break;

                    case >0:
                        double x1 = (-b + Math.Sqrt(D)) / (2 * a);
                        double x2 = (-b - Math.Sqrt(D)) / (2 * a);
                        client.SendMessage(Channel(), $"D = {D}, x1 = {x1}, x2 = {x2}");
                    break;
                }
            }
            catch
            {
                client.SendMessage(Channel(), $"error, enter your numbers of equasion like {quot}#quadratic a b c{quot}");
            }
        }
    }
}