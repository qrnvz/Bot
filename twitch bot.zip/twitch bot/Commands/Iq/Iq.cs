using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Iq : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            try
            {                        
                int iq = rnd.Next(0, 200);
                string user = e.Command.ChatMessage.Message.Split(" ")[1];
                        
                client.SendMessage(Channel(), $"{user} have {iq}iq");
            }

            catch
            {      
                int iq = rnd.Next(0, 200);
                client.SendMessage(Channel(),$"@{e.Command.ChatMessage.Username} you have {iq}iq");
            }
        }
    }
}