using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Gay : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            try
            {
                int gay = rnd.Next(-1, 101);
                string user = e.Command.ChatMessage.Message.Split(" ")[1];
                
                if(gay == -1)
                {
                    client.SendMessage(Channel(), $"{user} -҉̟̠͓͆̀̎͢͞1̵̨͖̞̾͝%҈̢͈̜̝̆͡ gay AppaK");
                }  
                else if(gay < 79)
                {
                    client.SendMessage(Channel(), $"{user} {gay}% gay Kappa");
                }
                else if(gay > 79)
                {
                    client.SendMessage(Channel(), $"{user} {gay}% gay KappaPride");
                }
            }
            catch
            {
                int gay = rnd.Next(-1, 101);
                
                if(gay == -1)
                {
                    client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} you are -҉̟̠͓͆̀̎͢͞1̵̨͖̞̾͝%҈̢͈̜̝̆͡ gay AppaK");
                }    
                else if(gay < 79)
                {
                    client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} you are {gay}% gay Kappa");
                }
                else if(gay > 79)
                {
                    client.SendMessage(Channel(), $"@{e.Command.ChatMessage.Username} you are {gay}% gay KappaPride");
                }                
            }
        }
    }
}