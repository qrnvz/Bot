using TwitchLib.Client.Events;

namespace twitch_bot
{
    class MessageHandler : Bot
    {
        public static void Run(OnMessageReceivedArgs e)
        {

        }
    }
}