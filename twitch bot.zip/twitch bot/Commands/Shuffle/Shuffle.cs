using System.Collections.Generic;
using System.Linq;
using TwitchLib.Client.Events;

namespace twitch_bot
{
    class Shuffle : Bot
    {
        public static void Run(OnChatCommandReceivedArgs e)
        {
            List<string> input = new List<string>(e.Command.ChatMessage.Message.Split(" "));

            input.Remove(input[0]);
            List<string> shuffled = input.OrderBy(i => rnd.Next()).ToList();
            
            string result = string.Join(" ", shuffled);

            client.SendMessage(Channel(), result);
        }
    }
}