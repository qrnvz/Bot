using System;
using System.Threading;
using TwitchLib.Client.Models;
using TwitchLib.Client;
using TwitchLib.Client.Events;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace twitch_bot
{
    internal class Bot : Connect
    {
        public static ConnectionCredentials creds = new ConnectionCredentials(Channel(), Token());
        public static TwitchClient client = new TwitchClient();
        public static Random rnd = new Random();

        public static string target = "", targetShuffle = "", playAnswer, timeDisplay, shuffled, quizQuestion, quizAnswer = "", quizCategory, quizLang = "EN";
        public static bool whiteListed = false, quizRunning = false, quizStopped = false, quizAnswered = false, shufflerOn = false; 
        public static int quizQuestionTime, quizAnswerTime;
        public static char quot = '"';

        public static List<string> shuffledMessages = new List<string>();
        public static List<string> quizQuestionsRU = new List<string>();
        public static List<string> quizUsedQuestions = new List<string>();


        public static List<string> whiteList = new List<string>{"qrgdx"};

        internal void Connect()
        {
            client.Initialize(creds, Channel());
            
            client.OnChatCommandReceived += OnChatCommandReceived;
            client.OnMessageReceived += OnMessageReceived;
            client.OnLog += OnLog;
            client.OnConnected += OnConnected;
            
            client.Connect();

            client.RemoveChatCommandIdentifier('!');
            client.AddChatCommandIdentifier('#');
        }

        private void OnConnected(object sender, OnConnectedArgs e)
        {
            quizQuestionsRU = File.ReadAllLines("D:/C#/projects/twitch bot/Commands/Quiz/QuizQuestionsRU.txt", Encoding.Default).ToList();
        }

        private void OnLog(object sender, OnLogArgs e)
        {
            timeDisplay = Convert.ToString(e.DateTime.AddHours(2)).Split(" ")[1];
        }

        private void OnMessageReceived(object sender, OnMessageReceivedArgs e)
        {   
            Console.WriteLine($"[{timeDisplay}] {e.ChatMessage.Username}: {e.ChatMessage.Message}");

            if(e.ChatMessage.IsBroadcaster || e.ChatMessage.IsModerator || e.ChatMessage.IsVip)
            {
                if(!whiteList.Contains(e.ChatMessage.Username))
                {
                    whiteList.Add(e.ChatMessage.Username);
                }
            }

            if(e.ChatMessage.Username == "qrgdx")
            {
                if(e.ChatMessage.IsModerator || e.ChatMessage.IsVip || e.ChatMessage.IsBroadcaster)
                {
                    whiteListed = true;
                }
            }

            QuizAnswer.Run(e);

            RepeatMessages.Run(e);

            PlayAnswer.Run(e);

            ShufflerMessages.Run(e);
        }
        
        private void OnChatCommandReceived(object sender, OnChatCommandReceivedArgs e)
        {   
            Console.WriteLine($"[{timeDisplay}] {e.Command.ChatMessage.Username} used {e.Command.ChatMessage.Message}");

            if(whiteListed && e.Command.ChatMessage.Username == "qrgdx")
            {
                Thread.Sleep(0);
            }
            else if(e.Command.ChatMessage.Username == "qrgdx")
            {
                Thread.Sleep(1000);
            }
            
            switch(e.Command.CommandText.ToLower())
            {
                case "help":
                Help.Run(e);
                break;

                case "repeat":
                Repeat.Run(e);
                break;

                case "stop":
                Stop.Run(e);
                break;

                case "iq":
                Iq.Run(e);
                break;

                case "play":
                Play.Run(e);
                break;

                case "gay":
                Gay.Run(e);
                break;

                case "plus":
                Plus.Run(e);
                break;

                case "minus":
                Minus.Run(e);
                break;

                case "multiply":
                Multiply.Run(e);
                break;

                case "divide":
                Divide.Run(e);
                break;

                case "weather":
                Weather.Run(e);
                break;

                case "quadratic":
                Quadratic.Run(e);
                break;

                case "shuffle":
                Shuffle.Run(e);
                break;

                case "repeatshuffle":
                RepeatShuffle.Run(e);
                break;

                case "vanish":
                Vanish.Run(e);
                break;

                case "pyramid":
                Pyramid.Run(e);
                break;

                case "count":
                Count.Run(e);
                break;

                case "quiz":
                Quiz.Run(e);
                break;

                case "shuffler":
                Shuffler.Run(e);
                break;
            }

            if(whiteListed)
            {   
                Thread.Sleep(0);
            }
            else
            {
                Thread.Sleep(2000);
            }
        }

        internal void Disconnect()
        {   
            client.Disconnect();
        }
    }
}